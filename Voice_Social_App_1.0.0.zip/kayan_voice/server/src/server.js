const express=require('express'); const cors=require('cors');
const app=express(); app.use(cors()); app.use(express.json());
const state={users:[],rooms:[],agencies:[],transactions:[]};
app.get('/api/health',(req,res)=>res.json({ok:true,service:'Kayan Voice API',version:'0.1.0'}));
app.get('/api/rooms',(req,res)=>res.json(state.rooms));
app.post('/api/users',(req,res)=>{const u={id:Date.now(),role:'user',coins:0,...req.body};state.users.push(u);res.status(201).json(u)});
app.get('/api/users/:id',(req,res)=>{const u=state.users.find(x=>String(x.id)===req.params.id);u?res.json(u):res.status(404).json({error:'not_found'})});
app.post('/api/transactions',(req,res)=>{const t={id:Date.now(),createdAt:new Date().toISOString(),...req.body};state.transactions.push(t);res.status(201).json(t)});
app.listen(process.env.PORT||8080,()=>console.log('Kayan Voice API running'));
