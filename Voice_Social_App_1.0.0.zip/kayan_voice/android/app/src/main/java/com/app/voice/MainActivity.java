package com.app.voice;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; TextView title, coins; int gold=Color.rgb(240,185,70); int bg=Color.rgb(12,13,20); int card=Color.rgb(24,26,36); int muted=Color.rgb(160,164,178);
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(bg); build(); showHome();}
    TextView tv(String s,int sp,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); t.setPadding(8,8,8,8); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundColor(card); b.setPadding(8,8,8,8); return b; }
    LinearLayout box(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(16,16,16,16); l.setBackgroundColor(card); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,10,0,10);l.setLayoutParams(p);return l; }
    void build(){
      root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg); root.setPadding(16,18,16,12);
      LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); title=tv("التطبيق",24,true); head.addView(title,new LinearLayout.LayoutParams(0,-2,1)); coins=tv("💎 0",16,true); head.addView(coins); root.addView(head);
      content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); String[] ns={"الرئيسية","🎙 الغرف","💎 المحفظة","👤 حسابي"}; for(String n:ns){Button b=btn(n);nav.addView(b,new LinearLayout.LayoutParams(0,60,1)); if(n.contains("الغرف"))b.setOnClickListener(v->showRooms());else if(n.contains("المحفظة"))b.setOnClickListener(v->showWallet());else if(n.contains("حسابي"))b.setOnClickListener(v->showProfile());else b.setOnClickListener(v->showHome());} root.addView(nav);setContentView(root);
    }
    void clear(String t){content.removeAllViews();title.setText(t);}
    void showHome(){clear("التطبيق"); LinearLayout hero=box();hero.addView(tv("مرحبًا 👋",25,true));hero.addView(tv("منصة اجتماعية صوتية مستقلة — الاسم والهوية مؤقتًا بدون لوجو.",15,false));content.addView(hero);
      LinearLayout stats=box();stats.addView(tv("نشاط اليوم",18,true));stats.addView(tv("🎙 غرف نشطة    0\n👥 مستخدمون    0\n🎁 هدايا        0",16,false));content.addView(stats);
      Button rooms=btn("🎙 دخول الغرف الصوتية");rooms.setOnClickListener(v->showRooms());content.addView(rooms);
      Button events=btn("🏆 المهام والفعاليات");events.setOnClickListener(v->showEvents());content.addView(events);
      Button admin=btn("🛡 الإدارة");admin.setOnClickListener(v->showAdmin());content.addView(admin);
    }
    void showRooms(){clear("الغرف الصوتية"); String[] names={"الروم العام","جلسة الأصدقاء","فعاليات اليوم"}; for(String n:names){LinearLayout r=box();r.addView(tv("🎙 "+n,19,true));r.addView(tv("لا يوجد مضيفون الآن • 0 مستمع",14,false));Button b=btn("دخول الروم");b.setOnClickListener(v->toast("تم فتح واجهة الروم التجريبية"));r.addView(b);content.addView(r);}}
    void showWallet(){clear("المحفظة");LinearLayout w=box();w.addView(tv("💎 رصيدك",18,true));w.addView(tv("0 Coins",32,true));Button add=btn("➕ شحن Coins");add.setOnClickListener(v->toast("سيتم ربط بوابة الشحن بالسيرفر لاحقًا"));w.addView(add);content.addView(w);LinearLayout g=box();g.addView(tv("🎁 الهدايا",18,true));g.addView(tv("سجل الهدايا والمعاملات سيظهر هنا بعد ربط قاعدة البيانات.",14,false));content.addView(g);}
    void showProfile(){clear("حسابي");LinearLayout p=box();p.addView(tv("👤 مستخدم جديد",20,true));p.addView(tv("ID: —\nVIP: غير مفعل\nAgency: غير مرتبط",15,false));content.addView(p);Button login=btn("🔐 تسجيل الدخول / إنشاء حساب");login.setOnClickListener(v->toast("واجهة التسجيل جاهزة للربط بالـAPI"));content.addView(login);}
    void showEvents(){clear("المهام والفعاليات");String[] e={"🎯 تسجيل دخول يومي","🎙 استضافة ساعة","🎁 إرسال أول هدية","🏆 صدارة الأسبوع"};for(String x:e){LinearLayout a=box();a.addView(tv(x,18,true));a.addView(tv("المكافأة: قابلة للتعديل من لوحة الإدارة",14,false));content.addView(a);}}
    void showAdmin(){clear("لوحة الإدارة");String[] a={"👑 Owner — صلاحية كاملة","🛡 Super Admin — إدارة المستخدمين","🏢 Agencies — الوكلاء والمضيفون","💰 Coins / Gifts / Transactions","🏆 Rankings / Events","🔔 Notifications","⚙️ إعدادات السيرفر"};for(String x:a){Button b=btn(x);b.setOnClickListener(v->toast("هذه الوحدة مربوطة بالـAPI في النسخة الإنتاجية"));content.addView(b);}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
