# Standalone Voice Social App — v1.0.0

A clean independent starter for a social voice/chat platform. No previous app name, logo, assets, or server connection are included.

## Included
- Android client shell with Home, Rooms, Wallet, Profile, Events, Admin
- Independent application id: `com.app.voice`
- Node.js API starter
- SQL schema for users, roles, wallets, agencies, rooms, gifts, transactions, rankings, tasks and notifications

## Production requirements
A real production release still needs an Android build environment, a hosted API/database, authentication, realtime chat/voice (RTC), payment/recharge provider, push notifications, moderation, logging and security hardening.
